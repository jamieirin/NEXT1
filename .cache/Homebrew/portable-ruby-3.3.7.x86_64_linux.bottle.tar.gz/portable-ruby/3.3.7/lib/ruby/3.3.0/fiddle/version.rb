module Fiddle
  VERSION = "1.1.2"
end
