# frozen_string_literal: true

require_relative "syntax_suggest/core_ext"
