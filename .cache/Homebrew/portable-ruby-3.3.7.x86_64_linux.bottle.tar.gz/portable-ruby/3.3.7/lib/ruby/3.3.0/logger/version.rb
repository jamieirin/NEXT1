# frozen_string_literal: true

class Logger
  VERSION = "1.6.0"
end
